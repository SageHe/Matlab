clear all;close all

t = [10 40 70 100 130 160];
y = [188;102;60;18;16;5];
%Part a, calculating logs, zi=ln(vi) and their uncertainties
z = log(y);
z_uncert = [];
for i = 1:length(z)
    z_uncert = [z_uncert 1/sqrt(y(i))];
end
%Part b, 
%Weight matrix for part b
W = eye(length(t));
for i = 1:length(t)
    W(i,i) = y(i);
end
%Create A matrix
A = [t(:) ones(length(t),1)];
%Solving for m and b, take inverse
out = A\z;
%inverse of b value gives you mean life of the material
mean_life = 1/out(1);
%Calcualate Q matrix for uncertainties
Q = inv(transpose(A)*W*A);
%Find unvertainty in m value
T_uncert = sqrt(Q(1));
%Plot ln(y) vs t along with best fit line
err = ones(1,6) .* z_uncert;
hold on 

plot(t,z,'*')
plot(t,out(1)*t+out(2))
errorbar(t,out(1)*t+out(2),err)
title('Number of Emissions vs Time')
xlabel('Time(minutes)')
ylabel('Number of Emissions')
legend('plotted points','straight-fit line')

fileID = fopen('leastsquares8.26.txt','w');
fprintf(fileID,'The materials mean life tau was calculated as %.5f with an uncertainty of %.5f \n',mean_life,T_uncert);
fprintf(fileID,'\n');
fprintf(fileID,'t values: \n %d %d %d %d %d %d \n',t(1),t(2),t(3),t(4),t(5),t(6));
fprintf(fileID,'v values: \n %d %d %d %d %d %d \n',y(1),y(2),y(3),y(4),y(5),y(6));
fprintf(fileID,'z=ln(v): \n %.3f %.3f %.3f %.3f %.3f %.3f',z(1),z(2),z(3),z(4),z(5),z(6));
fprintf(fileID,'Prof. Jacksons method was used in this problem, so there are no sums to display for this problem');