clear all;close all
t = [-2 -1 0 2];
y = [4 3 1 0];
%Find best fit line to data in form y=Beta_naught + Beta_one*t
%Construct A and b matrices to solve for Beta_naught and Beta_one values
A = [-2;-1;0;2];
A = [A [1;1;1;1]];
y = [4;3;1;0];
out = A\y;
Beta_naught = out(2);
Beta_one = out(1);
Y = Beta_naught + Beta_one*t;
delta = 4*sum(t.^2) - (sum(t)).^2;
newa = ((sum(t.^2)*(sum(Y)) - sum(t)*sum(t.*Y))/delta);
newb = ((4*sum(t.*Y) - sum(t)*sum(Y))/delta);


hold on

plot(t,y,'*')
plot(t,t*Beta_one+Beta_naught)
%Part 2, determine uncertainty in y measurement 
sigmay = [];
for i = 1: length(y)
    sigmay = [sigmay (y(i) - newa - newb*t(i)).^2];
end
sigmay = sum(sigmay);
sigmay1 = sqrt((1/2)*sigmay);
%Part 3, determine uncertainty in Beta_naught and Beta_one coefficients
%Use A and B uncertainties from book based on uncertainty in y, sigmay
Beta_naught_uncert = sigmay*sqrt((sum(t.^2))/delta);
Beta_one_uncert = sigmay*sqrt(4/delta);
%Part 4, find best quadratic polynomial fit to data in form
%y=Beta_two+Beta_three*t+Beta_four*t^2
t = t(:);
out = polyfit(t,y,2);
Beta_four = out(1);
Beta_three = out(2);
Beta_two = out(3);
clear out
%Part 5, determine uncertainty in measurements of y using a quadratic
%polynomial fit
Y = Beta_two + Beta_three*t + Beta_four.*t.^2;
delta = 4*sum(t.^2) - (sum(t)).^2;
newa = ((sum(t.^2)*(sum(Y)) - sum(t)*sum(t.*Y))/delta);
newb = ((4*sum(t.*Y) - sum(t)*sum(Y))/delta);

sigmay = [];
for i = 1: length(y)
    sigmay = [sigmay (y(i) - Beta_two - Beta_three*t(i) - Beta_four.*(t(i).^2)).^2];
end
sigmay = sum(sigmay);
sigmay = sqrt((1/2)*sigmay);
%Part6, determine uncertainties in Beta_two, Beta_three, and Beta_four
W = eye(4);
W = W*(1/(sigmay).^2);
%Compute Q matrix using built W and A matrix 
A = [t(1)^2 t(1) 1;t(2)^2 t(2) 1;t(3)^2 t(3) 1;t(4)^2 t(4) 1];
Q = inv(transpose(A)*W*A);
Beta_four_uncert = sqrt(Q(1,1));
Beta_three_uncert = sqrt(Q(2,2));
Beta_two_uncert = sqrt(Q(3,3));
%Part 7, plot data, best straight-fit line, and best quadratic polynomial
%fit line
plot(t,Beta_four.*t.^2+Beta_three.*t+Beta_two)
legend('plotted points','straight-fit line','polynomial fit line')
title('Straight-line fit vs polynomial line fit')
xlabel('t')
ylabel('Y')
fileID = fopen('leastsquares_non_textbook.txt','w');
fprintf(fileID,'The straight line fit is given by the equation y = -1.2866X + 1.7429 with an uncertainty of .6094. Beta naught had an uncetainty of .3767. Beta 1 had an uncertainty of .2511 \n');
fprintf(fileID,'The best quadratic polynomial fit had the form y = 1.3273 - 1.0545t + .1818t^2. Beta2 had an uncertainty of 1.3273, Beta3 had an uncertainty of .1377. Beta4 had an uncertainty of .1141 \n'); 
fclose(fileID);